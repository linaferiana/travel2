<?php

include 'koneksi.php';

$kodepesawat= $_POST['kode_pesawat'];
$namapesawat= $_POST['nama_pesawat'];
$pilot= $_POST['pilot'];
$kelaskabin= $_POST['kelas_kabin'];
$harga= $_POST['harga'];



 mysqli_query($dbconnect, "INSERT INTO admin VALUES ( NULL, '$kodepesawat','$namapesawat','$pilot','$kelaskabin','$harga')");

 header("location:databarang.php")
 ?>