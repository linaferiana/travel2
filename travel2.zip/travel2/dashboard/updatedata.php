<!doctype html>
<html lang="en">
 <head>
 	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<meta name="description" content="">
 	<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
 	<meta name="generator" content="Hugo 0.88.1">
 	<title>Admin | Data Admin-Update Data</title>

 	<link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/dashboard/">




 <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">

 	<style>
 		.bd-placeholder-img {
 			font-size: 1.125rem;
 			text-anchor: middle;
 			-webkit-user-select: none;
 			-moz-user-select: none;
 			user-select: none;
		}

		@media (min-width: 768px) {
			.bd-placeholder-img-lg {
				font-size: 3.5rem;
			}
		}
 	</style>



 	<link href="dashboard.css" rel="stylesheet">
 	</head>
 	<body>
 		
 <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
 	<a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">Travel And Tour</a>
 	<button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
 		<span class="navbar-toggler-icon"></span>
 	</button>
 	<input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
 	<div class="navbar-nav">
 		<div class="nav-item text-nowrap">
 			<a class="nav-link px-3" href="#">Logout</a>
 		</div>
 	</div>
</header>

<div class="container-fluid">
	<div class="row">
		<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
			<div class="position-sticky pt-3">
				<ul class="nav flex-column">
					<li class="nav-item">
						<a class="nav-link" aria-current="page" href="index.html">
						<span data-feather="home"></span>
							Dashboard
						</a>
					</li>
				<li class="nav-item">
					<a class="nav-link active" href="databarang.php">
						<span data-feather="file"></span>
							Data Barang						
						</a>
					</li>
				</ul>
			</div>
		</nav>

		<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2">Edit Data Barang</h1>
		</div>


		<section>
			

			<form action="prosesupdate.php" method="post">
				
				<?php
				include 'koneksi.php';
				$id=$_GET['id'];
				$query = mysqli_query($dbconnect, "SELECT * FROM admin WHERE id = '$id' ");

				$tampil = mysqli_fetch_assoc($query);

				?>
		<section>
			<section>
				<section>
					<div class="mb-3">
			<label for="id" class="form-label">Id</label>
			<input type="text"  class="form-control" id="id" name="id" readonly value="<?php echo $tampil ['id']?>">
					</div>
					<div class="mb-3">
			<label for="kode_pesawat" class="form-label">Kode_Pesawat</label>
			<input type="text" class="form-control" id="kode_pesawat" name="kode_pesawat" value="<?php echo $tampil ['kode_pesawat']?>">
					</div>
					<div class="mb-3">
			<label for="nama_pesawat" class="form-label">Nama_Pesawat</label>
			<input type="text"  class="form-control" id="nama_pesawat" name="nama_pesawat" value="<?php echo $tampil ['nama_pesawat']?>">
					</div>
					<div class="mb-3">
			<label for="pilot" class="form-label">PIlot</label>
			<input type="text"  class="form-control" id="pilot" name="pilot" value="<?php echo $tampil ['pilot']?>">
					</div>
					<div class="mb-3">
			<label for="kelas_kabin" class="form-label">Kelas_Kabin</label>
			<input type="text"  class="form-control" id="kelas_kabin" name="kelas_kabin" value="<?php echo $tampil ['kelas_kabin']?>">
					</div>
					<div class="mb-3">
			<label for="harga" class="form-label">Harga</label>
			<input type="number"  class="form-control" id="harga" name="harga" value="<?php echo $tampil ['harga']?>">
					</div>
					<div class="mb-3">
						<button type="submit" name="inputdata" class="btn btn-primary" onclick="return confirm('apakah anda yakin ingin mengubah data tersebut?')">Ubah</button>
					</div>
				</section>
			</section>
		</section>
			</form>
		</section>
		</main>
  </div>
</div>

		<script type="text/javascript" src="../assets/js/bootstrap.bundle.min.js"></script>

		<script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="dashboard.js"></script>
 	</body>
 </html>