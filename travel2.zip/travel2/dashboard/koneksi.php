<?php

$host = "localhost";
$user = "root";
$pass = "";
$db	  = "travel";

$dbconnect = new mysqli("$host","$user","$pass","$db");

?>